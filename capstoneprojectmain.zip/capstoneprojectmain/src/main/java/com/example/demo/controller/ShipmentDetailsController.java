package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.modal.ShipmentDetails;
import com.example.demo.repo.ShipmentDetailsRepo;


@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/pmt")
public class ShipmentDetailsController {
	
	@Autowired
	private ShipmentDetailsRepo ShipmentDetailsRepo;
	
	 @PostMapping("/ShipmentDetails")
	    public ShipmentDetails createShipmentDetails(@RequestBody ShipmentDetails ShipmentDetails) {
		 return ShipmentDetailsRepo.save(ShipmentDetails);
	    }

}
