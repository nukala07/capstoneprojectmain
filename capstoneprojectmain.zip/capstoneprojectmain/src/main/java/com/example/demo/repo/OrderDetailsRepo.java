package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.modal.OrderDetails;



public interface OrderDetailsRepo extends JpaRepository<OrderDetails, String>{

}


